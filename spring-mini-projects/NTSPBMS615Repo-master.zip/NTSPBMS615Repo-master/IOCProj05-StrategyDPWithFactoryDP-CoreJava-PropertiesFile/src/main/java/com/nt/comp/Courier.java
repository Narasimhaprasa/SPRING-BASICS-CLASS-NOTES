package com.nt.comp;

public interface Courier {
     public String  deliver(int oid);
}
