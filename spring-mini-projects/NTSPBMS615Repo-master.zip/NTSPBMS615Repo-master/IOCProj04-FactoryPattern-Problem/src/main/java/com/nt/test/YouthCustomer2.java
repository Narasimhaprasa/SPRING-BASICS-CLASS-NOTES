//YouthCustomer2.java
package com.nt.test;

import com.nt.comp.BudgetCar;
import com.nt.comp.Car;
import com.nt.comp.SportsCar;

public class YouthCustomer2 {
	public static void main(String[] args) {
		Car car=new SportsCar("TS10 KK 5656");
		car.drive();
		
	}

}
