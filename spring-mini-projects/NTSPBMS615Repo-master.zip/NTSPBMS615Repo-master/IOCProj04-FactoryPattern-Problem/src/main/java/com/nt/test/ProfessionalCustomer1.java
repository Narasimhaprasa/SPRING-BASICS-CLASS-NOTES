//ProfessionalCustomer1.java
package com.nt.test;

import com.nt.comp.BudgetCar;
import com.nt.comp.Car;

public class ProfessionalCustomer1 {
	public static void main(String[] args) {
		Car car=new BudgetCar("TS09EN 5656");
		car.drive();
		
	}

}
