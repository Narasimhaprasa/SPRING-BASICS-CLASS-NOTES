package com.nt.comp;

public abstract class Car {
    public abstract  void drive();
}
