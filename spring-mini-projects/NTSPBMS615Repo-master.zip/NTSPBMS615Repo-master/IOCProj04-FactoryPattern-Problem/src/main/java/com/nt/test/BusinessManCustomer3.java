//BusinessManCustomer3 .java
package com.nt.test;

import com.nt.comp.BudgetCar;
import com.nt.comp.Car;
import com.nt.comp.LuxoryCar;
import com.nt.comp.SportsCar;

public class BusinessManCustomer3 {
	public static void main(String[] args) {
		Car car=new LuxoryCar("TS11 AB 5151");
		car.drive();
		
	}

}
