package com.nt.service;

import com.nt.dto.EmployeeDTO;

public interface IEmployeeMgmtService {
    public  String registerEmployee(EmployeeDTO dto)throws Exception;
}
