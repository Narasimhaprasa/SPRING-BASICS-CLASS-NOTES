package com.nt.dao;

import com.nt.bo.EmployeeBO;

public interface IEmployeeDAO {
   public int  insertEmployee(EmployeeBO bo)throws Exception;
}
